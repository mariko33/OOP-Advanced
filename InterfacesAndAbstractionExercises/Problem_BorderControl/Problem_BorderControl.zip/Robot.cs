﻿public class Robot:Society
{
    public Robot(string name, string id) : base(name, id)
    {
    }
}
