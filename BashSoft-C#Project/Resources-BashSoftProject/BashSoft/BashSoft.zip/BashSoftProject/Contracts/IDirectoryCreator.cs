﻿namespace BashSoftProject.Contracts
{
    public interface IDirectoryCreator
    {
        void CreateDirectoryInCurrentFolder(string name);
    }
}