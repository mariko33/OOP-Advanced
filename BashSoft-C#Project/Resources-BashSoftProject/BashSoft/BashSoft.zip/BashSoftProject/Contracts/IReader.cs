﻿namespace BashSoftProject.Contracts
{
    public interface IReader
    {
        void StartReadingCommands();
    }
}