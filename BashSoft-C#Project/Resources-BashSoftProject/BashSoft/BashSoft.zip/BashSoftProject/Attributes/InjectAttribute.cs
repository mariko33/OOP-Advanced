﻿using System;

namespace BashSoftProject.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class InjectAttribute:Attribute
    {
        
    }
}