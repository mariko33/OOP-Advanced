﻿using System.IO;

namespace BashSoftProject.Static_data
{
    public static class SessionData
    {
        public static string currentPath = Directory.GetCurrentDirectory();
    }
}